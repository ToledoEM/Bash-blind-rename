//
//  BashBlindRenameTests.swift
//  BashBlindRenameTests
//
//  Created by enrique on 06/07/2025.
//

import Testing

struct BashBlindRenameTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
