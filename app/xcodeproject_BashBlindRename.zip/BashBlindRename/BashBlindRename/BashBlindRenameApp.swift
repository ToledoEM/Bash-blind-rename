//
//  BashBlindRenameApp.swift
//  BashBlindRename
//
//  Created by enrique on 06/07/2025.
//

import SwiftUI

@main
struct BashBlindRenameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
